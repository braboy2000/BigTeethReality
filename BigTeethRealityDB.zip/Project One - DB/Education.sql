CREATE TABLE Education (
    [ApplicantID] INT,
    [Education] NVARCHAR(26),
    [Contact] NVARCHAR(12),
    [Degree] NVARCHAR(9),
    [Comments] NVARCHAR(16)
);
INSERT INTO Education VALUES
    (1,N'Cal Poly',N'734-344-6180',N'Master',N'Graduated'),
    (2,N'UC Davis',N'785-995-5982',N'Associate',N'Graduated'),
    (3,N'UC San Diego',N'707-202-5534',N'Bachelor',N'Graduated'),
    (4,N'CSU Sacramento',N'912-334-8647',N'Associate',N'Graduated'),
    (5,N'Fullerton',N'712-338-9527',N'Associate',N'Graduated'),
    (6,N'University of Pennsylvania',N'570-739-7456',N'Associate',N'Graduated'),
    (7,N'UCLA',N'651-558-3949',N'Master',N'Never attended'),
    (8,N'Consumnes River College',N'857-404-2898',N'Bachelor',N'Graduated'),
    (9,N'Delta College',N'828-292-9709',N'Associate',N'Graduated'),
    (10,N'CSU Stockton',N'423-822-2442',N'Bachelor',N'Graduated'),
    (7,N'UC Irvine',N'305-528-3662',N'Bachelor',N'Did not graduate');
