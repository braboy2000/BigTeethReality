CREATE TABLE Actions (
    [EventID] INT,
    [Description] NVARCHAR(48),
    [Cameras] NVARCHAR(39),
    [Est_Time] NVARCHAR(8),
    [Sequence] INT
);
INSERT INTO Actions VALUES
    (1,N'Sharks are put in cage',N'Underwater',N'00:05:00',1),
    (1,N'Players enter water',N'Aerial helicopter',N'00:05:00',2),
    (1,N'Sharks are let out',N'Underwater',N'00:05:00',3),
    (1,N'Players race',N'Go Pro attached to foreheads of players',N'00:05:00',4),
    (2,N'Sharks are caught and gathered',N'Table',N'00:10:00',1),
    (2,N'Players eat sharks',N'Aerial drone',N'00:10:00',2),
    (3,N'Alligators are gathered in pit',N'Aerial drone',N'00:10:00',1),
    (3,N'Tightrope is set',N'Bench',N'00:10:00',2),
    (3,N'Players walk or hang on tightrope',N'Go Pros attached to alligators',N'00:10:00',3),
    (4,N'Decayed corpses are set on table',N'Table',N'00:10:00',1),
    (4,N'Players eat corpses',N'Go Pros attached to player foreheads',N'00:20:00',2),
    (5,N'Players try and steal baby hippos from enclosure',N'Aerial drone',N'00:30:00',1),
    (6,N'Tigers gathered into man-made jungle',N'Attached to enclosure fence',N'00:10:00',1),
    (6,N'Players try to reach end of jungle',N'Aerial drone',N'00:20:00',2);
