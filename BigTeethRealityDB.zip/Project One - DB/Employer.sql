CREATE TABLE Employer (
    [ApplicantID] INT,
    [Employer] NVARCHAR(20),
    [Phone] NVARCHAR(12),
    [Comments] NVARCHAR(19),
    [EmployerID] INT
);
INSERT INTO Employer VALUES
    (1,N'Great Clips',N'812-471-4155',N'Unfriendly',1),
    (1,N'NASA',N'201-909-5721',N'Never worked there',2),
    (2,N'Mario''s',N'586-482-4117',N'Enjoyed his job',3),
    (3,N'Booker Middle School',N'408-302-7666',N'Team player',4),
    (4,N'KFC',N'570-436-9528',N'Loved to cook',5),
    (5,N'Kaiser Permanente',N'304-802-7018',N'Enthusiastic',6),
    (6,N'Sawdust',N'724-343-2011',N'Best worker',7),
    (6,N'Marksman Center',N'510-446-8780',N'Friendly',8),
    (7,N'Disney',N'601-705-6679',N'Always late to work',9),
    (8,N'Funk Parlor',N'516-590-4923',N'Funny',10),
    (9,N'Clairvoyant',N'786-410-4166',N'Helpful',11),
    (9,N'Oracle',N'606-331-4933',N'Charismatic',12);
