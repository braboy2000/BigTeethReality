CREATE TABLE Jobs (
    [ApplicantID] INT,
    [Job] NVARCHAR(24),
    [Start] DATETIME,
    [End] DATETIME,
    [Description] NVARCHAR(38),
    [EmployerID] INT
);
INSERT INTO Jobs VALUES
    (1,N'Hairdresser','1989-02-18 00:00:00','1990-09-12 00:00:00',N'Cut hair, washed hair,  trimmed beards',1),
    (1,N'Astronaut','1995-01-01 00:00:00',NULL,N'Currently an astronaut for the USS',2),
    (2,N'Chef','2000-07-31 00:00:00',NULL,N'Cooks pizza at Mario''s pizzeria',3),
    (3,N'Counselor','2022-01-23 00:00:00',NULL,N'Counselor at local middleschool',4),
    (4,N'Cashier and food prepper','2021-03-17 00:00:00',NULL,N'Handled money and distributed food',5),
    (5,N'Nurse','2020-04-02 00:00:00',NULL,N'Nurse at Kaiser Hospital',6),
    (6,N'Carpenter','2010-05-27 00:00:00','2012-07-05 00:00:00',N'Carpenter for dad''s woodshop',7),
    (6,N'Gunsmith','2021-06-12 00:00:00',NULL,N'Modifying and repairing guns',8),
    (7,N'Magician','2015-10-10 00:00:00',NULL,N'Card tricks and spells',9),
    (8,N'Musician','2013-08-09 00:00:00',NULL,N'Jazz soloist',10),
    (9,N'IT Techician','2013-05-30 00:00:00','2015-05-22 00:00:00',N'Network support specialist',11),
    (9,N'Data Analyst','2016-11-19 00:00:00',NULL,N'Collect,  clean,  and interpret data',12);
