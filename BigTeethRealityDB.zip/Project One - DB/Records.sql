CREATE TABLE Records (
    [ApplicantID] INT,
    [Date] DATETIME,
    [Category] NVARCHAR(11),
    [Description] NVARCHAR(19),
    [Outcome] NVARCHAR(15)
);
INSERT INTO Records VALUES
    (1,'1990-03-21 00:00:00',N'Infraction',N'Speeding',N'Guilty'),
    (3,'2021-08-23 00:00:00',N'Felony',N'Burglary',N'Not Guilty'),
    (4,'2022-03-15 00:00:00',N'Misdemeanor',N'Shoplifting',N'Not Guilty'),
    (7,'2020-06-10 00:00:00',N'Misdemeanor',N'Arson',N'Guilty'),
    (7,'2021-02-05 00:00:00',N'Felony',N'Assault and Battery',N'Guilty'),
    (9,'2020-01-02 00:00:00',N'Infraction',N'Moving violation',N'Guilty'),
    (9,'2022-02-20 00:00:00',N'Infraction',N'Moving violation',N'Not Guilty'),
    (10,'2016-04-17 00:00:00',N'Felony',N'DUI',N'Guilty'),
    (2,NULL,NULL,NULL,N'No record found'),
    (5,NULL,NULL,NULL,N'No record found'),
    (6,NULL,NULL,NULL,N'No record found');
