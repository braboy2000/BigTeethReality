CREATE TABLE TotalVotes (
    [ApplicantID] INT,
    [VoteTotals] INT
);
INSERT INTO TotalVotes VALUES
    (5,10215000),
    (6,10750000),
    (8,14790000);
