CREATE TABLE Event (
    [Title] NVARCHAR(12),
    [Episode] INT,
    [Description] NVARCHAR(57),
    [Estimated_time] NVARCHAR(8),
    [Estimated_danger] INT,
    [Producer] NVARCHAR(13),
    [Director] NVARCHAR(14),
    [EventID] INT
);
INSERT INTO Event VALUES
    (N'Water Tank',1,N'Players will try to outswim sharks',N'00:20:00',10,N'Yvette Olson',N'Garrett Chavez',1),
    (N'Rubber',1,N'Players will compete for fastest time to eat alive sharks',N'00:20:00',8,N'Yvette Olson',N'Garrett Chavez',2),
    (N'Chomp',2,N'Players will tightrope over alligator infested waters',N'00:30:00',9,N'Yvette Olson',N'Garrett Chavez',3),
    (N'Corpse Party',3,N'Players will eat decomposed lion corpses',N'00:30:00',1,N'Yvette Olson',N'Garrett Chavez',4),
    (N'Oh no hippo',4,N'Players will attempt to steal baby hippos from mom hippo',N'00:30:00',7,N'Yvette Olson',N'Garrett Chavez',5),
    (N'Stealth',5,N'Players will traverse man-made jungle filled with tigers',N'00:30:00',8,N'Pedro Gilbert',N'Sally Abbott',6);
