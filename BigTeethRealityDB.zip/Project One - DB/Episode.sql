CREATE TABLE Episode (
    [Episode_Title] NVARCHAR(16),
    [Episode] INT,
    [Air_Date] DATETIME
);
INSERT INTO Episode VALUES
    (N'Jaws',1,'2020-01-16 00:00:00'),
    (N'Alligator Pit',2,'2020-01-29 00:00:00'),
    (N'Try not to Barf',3,'2020-02-12 00:00:00'),
    (N'All bets are off',4,'2020-03-20 00:00:00');
