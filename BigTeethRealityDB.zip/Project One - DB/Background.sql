CREATE TABLE Background (
    [ApplicantID] INT,
    [NationalID] NVARCHAR(11),
    [Religion] NVARCHAR(10),
    [StrengthRating] INT,
    [AppearanceRating] INT
);
INSERT INTO Background VALUES
    (1,N'723-58-0185',N'Buddhist',6,6),
    (2,N'025-60-0796',N'Catholic',4,1),
    (3,N'442-34-7728',N'Atheist',5,2),
    (4,N'105-72-3733',N'Christian',3,7),
    (5,N'574-64-3725',N'Protestant',8,9),
    (6,N'103-28-7994',N'Hindu',9,10),
    (7,N'207-70-0477',N'Islam',5,3),
    (8,N'599-98-3817',N'Sik',10,9),
    (9,N'474-08-0491',N'Jewish',10,10);
