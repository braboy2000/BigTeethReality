CREATE TABLE Medications (
    [ApplicantID] INT,
    [Medication] NVARCHAR(10),
    [Reason] NVARCHAR(19)
);
INSERT INTO Medications VALUES
    (1,N'Neurotin',N'Seizures'),
    (1,N'Glucophage',N'Type 2 Diabetes'),
    (1,N'Flonase',N'Asthma'),
    (3,N'Synthroid',N'Thyroid problems'),
    (5,N'Prinivil',N'High blood pressure'),
    (5,N'Zyban',N'Anti-depressant'),
    (7,N'Lipitor',N'High cholesterol'),
    (9,N'Ventolin',N'Breathing problems');
