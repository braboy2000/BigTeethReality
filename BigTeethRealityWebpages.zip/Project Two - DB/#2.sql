SELECT Description, EstimatedTime
FROM Actions
ORDER BY EstimatedTime DESC