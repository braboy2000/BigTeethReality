SELECT MAX([Estimated danger]) AS MaxDanger
FROM Event