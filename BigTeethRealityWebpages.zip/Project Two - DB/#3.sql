SELECT ApplicantID, SUM(Votes) AS totalVotes, Voting.Episode, Episode.EpisodeTitle, Voting.Region, Voting.Method
FROM Voting
JOIN Episode ON Voting.Episode=Episode.Episode
WHERE Episode.EpisodeTitle='Jaws'
GROUP BY ApplicantID, Voting.Episode, Episode.EpisodeTitle, Voting.Region, Voting.Method
ORDER BY totalVotes DESC