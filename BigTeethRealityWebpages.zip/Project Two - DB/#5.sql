SELECT Application.ApplicantID
FROM Application
WHERE Application.ApplicantID NOT IN (SELECT ApplicantID FROM Contestants)