SELECT AVG(Points) AS AveragePoints, Event.EventID, Event.Title
FROM Contestants
JOIN Event ON Contestants.EventID=Event.EventID
WHERE Event.Title='Water Tank'
GROUP BY Event.EventID, Event.Title