SELECT TOP 2 ApplicantID
FROM Records
GROUP BY ApplicantID
ORDER BY COUNT(ApplicantID) DESC